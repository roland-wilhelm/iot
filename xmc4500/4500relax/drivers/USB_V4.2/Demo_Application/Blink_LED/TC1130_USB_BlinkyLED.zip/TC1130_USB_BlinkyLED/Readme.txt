This GUI has to be used with Thesycon's USBIO VL 2.3 only!!
