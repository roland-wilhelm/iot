/******************************************************************************
*
*        Copyright (c) 1999-2005, Infineon Technologies AG
*              Infineon Confidential Proprietary
*
*******************************************************************************
*/


#ifndef __MYREADER_H__
#define __MYREADER_H__

// get includes from USBIOLIB
#include "UsbIoReader.h"


//
// CMyReader class
//
// Provides a specialized Reader implementation
// by overwriting some of the virtual functions of the 
// base class CUsbIoReader.
//
class CMyReader : public CUsbIoReader
{
public:
  // default constructor
  CMyReader(int ByteSize);
  // destructor
  ~CMyReader();

  // Get Transfer Status
  int GetTransStatus(void);

  // Get Number of Bytes Read
  int GetNoBytesRead(void);

  // Get Buffer Pointer
  UCHAR* GetBufferPtr(void);

  // Reset Buffer
  void ResetBuffer(void);

// Get Data
  int GetData(UCHAR* pBuffer);

  // udo
  //char *glbl_ptr;
  UCHAR * return_p();
  // udo ende

private:
  UCHAR *actual_ptr;
  int   BufferByteSize;
  UCHAR *BufferPtr;
  int   TransStatus;
  int   NoBytesRead;
  
// implementation
protected :

  // ProcessData is called if a read operation completes.
  // The function checks for an error and processes the received
  // data if the read operation was successful.
  // overwritten from CUsbIoReader
  virtual void ProcessData(CUsbIoBuf* Buf);




};


#endif //__MYREADER_H__

/************************************ EOF *********************************/
