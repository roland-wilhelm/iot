//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TC1130_USB_BlinkyLED.rc
//
#define IDD_TC1130_USB_BlinkyLED_DIALOG   100
#define IDR_MAINFRAME                   128
#define IDC_OUTPUT                      1000
#define IDC_CANCELIO_BUTTON             1008
#define IDC_BULK_0_BUTTON               1100
#define IDC_BULK_0_EDIT                 1101
#define IDC_BULK_0_DATA                 1102
#define IDC_BULK_1_BUTTON               1103
#define IDC_BULK_1_EDIT                 1104
#define IDC_BUTTON1                     1200
#define IDC_BUTTON2                     1201
#define IDC_BUTTON3                     1202
#define IDC_BUTTON5                     1204
#define IDC_BUTTON6                     1205
#define IDC_BUTTON7                     1206
#define IDC_BUTTON8                     1207
#define IDC_BUTTON9                     1208
#define IDC_BUTTON10                    1209
#define IDC_EDIT1                       1210
#define IDC_BUTTON11                    1211
#define IDC_EDIT2                       1212
#define IDC_EDIT3                       1214
#define IDC_EDIT4                       1215
#define IDC_EDIT5                       1216
#define IDC_CHECK1                      1217
#define IDC_BUTTON4                     1218
#define IDC_EDIT6                       1219
#define IDC_BUTTON12                    1220
#define IDC_BUTTON13                    1221
#define IDC_BUTTON14                    1222
#define IDC_BUTTON15                    1223
#define IDC_BUTTON16                    1224
#define IDC_BUTTON17                    1225
#define IDC_BUTTON18                    1226
#define IDC_CHECK2                      1230
#define IDC_CHECK3                      1231
#define IDC_CHECK4                      1232
#define IDC_CHECK5                      1233

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1234
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
