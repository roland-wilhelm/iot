/******************************************************************************
*
*        Copyright (c) 1999-2005, Infineon Technologies AG
*              Infineon Confidential Proprietary
*
******************************************************************************/

#if !defined(AFX_TC1130_USB_BlinkyLED_H__567C5B89_02B2_4ECF_843A_721CB9F0DCF9__INCLUDED_)
#define AFX_TC1130_USB_BlinkyLED_H__567C5B89_02B2_4ECF_843A_721CB9F0DCF9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
    #error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include "UsbIoPipe.h"

/////////////////////////////////////////////////////////////////////////////
// CTC1130_USB_BlinkyLEDApp:
// See TC1130_USB_BlinkyLED.cpp for the implementation of this class
//

class CTC1130_USB_BlinkyLEDApp : public CWinApp
{
public:
    CTC1130_USB_BlinkyLEDApp();

// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CTC1130_USB_BlinkyLEDApp)
    public:
    virtual BOOL InitInstance();
    //}}AFX_VIRTUAL

// Implementation

    //{{AFX_MSG(CTC1130_USB_BlinkyLEDApp)
        // NOTE - the ClassWizard will add and remove member functions here.
        //    DO NOT EDIT what you see in these blocks of generated code !
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TC1130_USB_BlinkyLED_H__567C5B89_02B2_4ECF_843A_721CB9F0DCF9__INCLUDED_)
