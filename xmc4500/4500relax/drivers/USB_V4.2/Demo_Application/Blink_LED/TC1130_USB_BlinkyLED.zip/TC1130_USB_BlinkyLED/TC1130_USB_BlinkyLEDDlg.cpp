/******************************************************************************
*
*        Copyright (c) 1999-2005, Infineon Technologies AG
*              Infineon Confidential Proprietary
*
*******************************************************************************
*/

#include "stdafx.h"
#include <dbt.h>
#include "TC1130_USB_BlinkyLED.h"
#include "TC1130_USB_BlinkyLEDDlg.h"
#include <winioctl.h>
#include "setupapi.h"
#include "usbio_i.h"
#include "usbspec.h"
#include "MyWriter.h"
#include "MyReader.h"
#include "time.h"
#include "stdlib.h"
#include <fcntl.h>      /* Needed only for _O_RDWR definition */
#include <io.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "pattern_test.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

   
// global event, will be set if the worker thread terminates
HANDLE g_TerminateEvent = NULL;

// forward declarations
void CTC1130_USB_BlinkyLEDDlg::Start(int DevNb);

// For device recognition and DeviceChangeMsgStr(nEventType) message print 
//static const char* DeviceChangeMsgStr(UINT x);

/////////////////////////////////////////////////////////////////////////////
// CTC1130_USB_BlinkyLEDDlg dialog

CTC1130_USB_BlinkyLEDDlg::~CTC1130_USB_BlinkyLEDDlg()
{
}

CTC1130_USB_BlinkyLEDDlg::CTC1130_USB_BlinkyLEDDlg(CWnd* pParent /*=NULL*/)
    : CDialog(CTC1130_USB_BlinkyLEDDlg::IDD, pParent)
{
    //{{AFX_DATA_INIT(CTC1130_USB_BlinkyLEDDlg)
    m_Output        = _T("");
	  m_nb_of_loops   = XCP_NB_OF_LOOPS_DEFAULT;
  	//}}AFX_DATA_INIT

    // Note that LoadIcon does not require a subsequent DestroyIcon in Win32
    m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
    m_hKillEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
    m_hDevice = INVALID_HANDLE_VALUE;
    //m_hDevnotify = NULL;
}

void CTC1130_USB_BlinkyLEDDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CTC1130_USB_BlinkyLEDDlg)
	  DDX_Control(pDX, IDC_BUTTON16, m_close_device_pipes_ctrl);
  	DDX_Control(pDX, IDC_BUTTON4, m_inthread_stop);
   	DDX_Control(pDX, IDC_BUTTON3, m_inthread_start_ctrl);
	  DDX_Control(pDX, IDC_BUTTON9, m_bind_in_button_ctrl);
	  DDX_Control(pDX, IDC_BUTTON8, m_bind_out_button_ctrl);
	  DDX_Control(pDX, IDC_BUTTON15, m_idc_button15);
	  DDX_Text(pDX, IDC_OUTPUT, m_Output);
 	  DDX_Text(pDX, IDC_EDIT6, m_nb_of_loops);
	  DDX_Control(pDX, IDC_BUTTON1, m_On_generic_testCTRL);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTC1130_USB_BlinkyLEDDlg, CDialog)
    //{{AFX_MSG_MAP(CTC1130_USB_BlinkyLEDDlg)
    ON_WM_PAINT()
    ON_WM_QUERYDRAGICON()
    ON_BN_CLICKED(IDC_CANCELIO_BUTTON, OnCancelioButton)
    ON_WM_CLOSE()
  	ON_BN_CLICKED(IDC_BUTTON15, On_open_bind)
  	ON_BN_CLICKED(IDC_BUTTON16, On_close_dev_pipe)
  	ON_BN_CLICKED(IDC_BUTTON1, On_generic_test)
	  ON_BN_CLICKED(IDC_BUTTON3, On_inthread_start)
	  ON_BN_CLICKED(IDC_BUTTON4, On_stop_inthread)
  	ON_EN_CHANGE(IDC_EDIT6, On_nb_of_loops)
  	ON_BN_CLICKED(IDC_BUTTON8, On_bind_bulkout_ep)
  	ON_BN_CLICKED(IDC_BUTTON9, On_bind_bulkin_ep)
  	ON_BN_CLICKED(IDC_BUTTON10, On_do_all_on_right_side)
	ON_BN_CLICKED(IDC_BUTTON2, On_loop_over_test)
	ON_BN_CLICKED(IDC_BUTTON5, On_start_blinky)
	ON_BN_CLICKED(IDC_BUTTON6, On_stop_blinky)
	ON_BN_CLICKED(IDC_BUTTON7, On_faster_blink)
	ON_BN_CLICKED(IDC_BUTTON11, On_slower_blink)
	//}}AFX_MSG_MAP
ON_WM_DEVICECHANGE()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTC1130_USB_BlinkyLEDDlg message handlers

BOOL CTC1130_USB_BlinkyLEDDlg::OnInitDialog()
{
  // wichtig!! mit dieser Zeile kann man buttons auf aktivieren oder deaktivieren.
	CDialog::OnInitDialog();

   // Start Device Notification
  if (!RegisterDevNotify(g_UsbioID,&m_DevNotify)) {
    PrintMessage("ERROR: Unable to register device notification!\r\n");
  } 
   
  return TRUE;  // return TRUE  unless you set the focus to a control
}

//##################################################################
// // call the base implementation
//##################################################################

void CTC1130_USB_BlinkyLEDDlg::OnClose()
{
	CDialog::OnClose();
}

//##################################################################
// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.
//##################################################################

void CTC1130_USB_BlinkyLEDDlg::OnPaint() 
{
    if (IsIconic())
    {
        CPaintDC dc(this); // device context for painting

        SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

        // Center icon in client rectangle
        int cxIcon = GetSystemMetrics(SM_CXICON);
        int cyIcon = GetSystemMetrics(SM_CYICON);
        CRect rect;
        GetClientRect(&rect);
        int x = (rect.Width() - cxIcon + 1) / 2;
        int y = (rect.Height() - cyIcon + 1) / 2;

        // Draw the icon
        dc.DrawIcon(x, y, m_hIcon);
    }
    else
    {
            // enter the critical section
        m_OutputLock.Lock();
            // update the output window
        UpdateData(FALSE);
            // exit the critical section
        m_OutputLock.Unlock();
       
        CDialog::OnPaint();
    }
}

//##################################################################
// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
//##################################################################

HCURSOR CTC1130_USB_BlinkyLEDDlg::OnQueryDragIcon()
{
    return (HCURSOR) m_hIcon;
}


//##################################################################
// Print Message function 
//##################################################################

void CTC1130_USB_BlinkyLEDDlg::PrintMessage(LPCTSTR pFormat, ...)
{
    CString message;    // message string
    CEdit   *pEdit;     // output edit control
    va_list arguments;  // the argument list

    // initialize the argument pointer
    va_start(arguments, pFormat);
    // format the message string
    message.FormatV(pFormat, arguments);
    // reset the argument list
    va_end(arguments);
    // update the output window
    m_Output += message;
    UpdateData(FALSE);
    // get the edit control
    pEdit = (CEdit*)GetDlgItem(IDC_OUTPUT);
    // scroll to the bottom of the edit control
    pEdit->LineScroll(pEdit->GetLineCount());
   
}


//##################################################################
// Helper function
// Decodes an error code number as text 
//##################################################################

void CTC1130_USB_BlinkyLEDDlg::PrintError(DWORD Err)
{
  char strbuf[256];
  
  if ( Err != USBIO_ERR_SUCCESS ) {
     PrintMessage("ErrorCode %s \r\n",CUsbIo::ErrorText(strbuf,sizeof(strbuf),Err));
  }
} // PrintError




//##############################################################################################
// Not used at the moment
//##############################################################################################

void CTC1130_USB_BlinkyLEDDlg::OnCancelioButton() 
{ 

}


//##############################################################################################
// Register Device Notify function. Taken from Thesycon USBIO Application
// called in onInitDialog!
//##############################################################################################


BOOLEAN CTC1130_USB_BlinkyLEDDlg::RegisterDevNotify(const GUID g_UsbioID, HDEVNOTIFY *hDevNotify)
{
    
	DEV_BROADCAST_DEVICEINTERFACE NotificationFilter;


    ZeroMemory(&NotificationFilter, sizeof(NotificationFilter) );
    NotificationFilter.dbcc_size		= sizeof(DEV_BROADCAST_DEVICEINTERFACE);
    NotificationFilter.dbcc_devicetype	= DBT_DEVTYP_DEVICEINTERFACE;
	  NotificationFilter.dbcc_classguid	= g_UsbioID;
    
    // device notifications should be send to the main dialog
    *hDevNotify = RegisterDeviceNotification(m_hWnd,&NotificationFilter,DEVICE_NOTIFY_WINDOW_HANDLE);
   
	PrintMessage("RegisterDeviceNotification done\r\n");
	
	if ( !(*hDevNotify) ) {
      DWORD Err = GetLastError();
      PrintMessage("RegisterDeviceNotification failed, errcode:%08X\r\n",Err);
      return FALSE;
    }

    return TRUE;
}

//##############################################################################################
// Device Changed ?
//##############################################################################################

bool CTC1130_USB_BlinkyLEDDlg::OnDeviceChange(UINT nEventType, DWORD dwData)

{ 
	DEV_BROADCAST_DEVICEINTERFACE *data=(DEV_BROADCAST_DEVICEINTERFACE*)dwData;
	
	//PrintMessage("message: %08X (%s)\r\n",nEventType,DeviceChangeMsgStr(nEventType));


// check if data is valid
  if (data == NULL || data->dbcc_name == NULL || strlen(data->dbcc_name)==0) {
       return TRUE;
  }

  // convert interface name to CString
  CString Name(data->dbcc_name);
  //POSITION pos;

  // there is some strange behavior in Win98
  // there are notifications with dbcc_name = "."
  // we ignore this
  if (Name.GetLength() < 5) {
	 return TRUE;
  }

  switch (nEventType) {
  case DBT_DEVICEREMOVECOMPLETE:
    // a device with our interface has been removed or is stopped
    PrintMessage("The USB device %s has been removed.\r\n",data->dbcc_name);
    // close the global  handle
    if ( Dev.GetDevicePathName() && (0==Name.CompareNoCase(Dev.GetDevicePathName())) ) {
      PrintMessage("Closing driver interface\r\n");
      Dev.Close();
    }

    
   	// re-create device list
	  CUsbIo::CreateDeviceList(&g_UsbioID);
	
	break;
  
  case DBT_DEVICEARRIVAL:
    // a device with our interface has been activated (started)
    PrintMessage("IFX Device with USB_11d has been plugged in \r\n");
    PrintMessage("and is now available.\r\n"); 
    PrintMessage("Device path is: %s.\r\n",data->dbcc_name); 
	  //PrintMessage("Test will be started ..... \r\n");
    
    
    // Perform the whole test.
    //PrintMessage("if function would be enabled.... \r\n");
    //CTC1130_USB_BlinkyLEDDlg::On_do_all_on_right_side();
		    
    // create device list
		CUsbIo::CreateDeviceList(&g_UsbioID);
    
    break;
  case DBT_DEVICEQUERYREMOVE:
    // windows asked, if our device can be removed, we answer with TRUE (yes)
    PrintMessage("MSG: DBT_DEVICEQUERYREMOVE -- Application returned success.\r\n");
    break;
  case DBT_DEVICEREMOVEPENDING:
    // device remove is pending
    PrintMessage("MSG: DBT_DEVICEREMOVEPENDING.\r\n");
    break;
  default:
    break;
  } 

  return TRUE;
}



// ##################################################################
//  Update of GUI EDIT fields.
// ##################################################################


void CTC1130_USB_BlinkyLEDDlg::On_nb_of_loops() 
{
UpdateData(TRUE);
}



void CTC1130_USB_BlinkyLEDDlg::On_loop_over_test() 
{
  PrintMessage("This button is out of order!\r\n");
  /*
	int i=0;


  for (i=0; i<m_nb_of_loops; i++)
  {

    CTC1130_USB_BlinkyLEDDlg::On_generic_test(); 
    
    if (!(i%10))
    {
    PrintMessage("Loop #%d!\r\n", i);
    }
  
  }
   
  PrintMessage("Loop finished! \r\n");
  return;

*/
}

//#########################################################
// WRITE Function for BLINKY Start,Stop, Faster and Slower
//#########################################################

void CTC1130_USB_BlinkyLEDDlg::WriteDevice(char c)
{
	DWORD ByteCount = 0x40;
	unsigned char tbuffer[0x40];
	CUsbIoBuf BufferDesc(64);
  DWORD TransSize,i;
  int i1=0;
  int NoPktReceived=0;
  UCHAR pReceiveBuffer[512];

  for ( i=0; i<64; i++ ) {
    tbuffer[i] = 0x0;
  }

  tbuffer[0] = c;

  // Copy the data
  memcpy((UCHAR*)BufferDesc.Buffer(),tbuffer, 64);

  // set the length of the transfer in bytes
  TransSize = 64;
  
   
  BufferDesc.NumberOfBytesToTransfer = 64;
  
  // Write Asynchron
  Pipe_out_ep.Write(&BufferDesc);


  for (;;) {
      // wait for 100 ms 
      Status = Pipe_out_ep.WaitForCompletion(&BufferDesc,100);
      // check the status
      if (Status == USBIO_ERR_SUCCESS) {
          PrintMessage("Async write passed!\r\n");
          break;
      }   
      if (Status == USBIO_ERR_TIMEOUT) {
          PrintMessage("Async write not finished yet!\r\n");
      } else {
          PrintMessage("Async write failed! Any Other error\r\n");
          PrintError(Status);
          break;
      }
        
  }//for


  // Read Answer which gives LED State and Speed

  // Check receive buffer ever 10th millisecond and abort after 10 tries.
  while((NoPktReceived!=64) && (i1<10)) {
    Sleep(10);
    i1++;
    NoPktReceived = Pipe_in_ep.GetData(pReceiveBuffer);
  }
  
    
  if (NoPktReceived==0) {
    PrintMessage("No Status report received!\r\n");
  } else {
    if (pReceiveBuffer[0]!=0x0) {
     PrintMessage("LED State: Blinking..\r\n");
   } else {
     PrintMessage("LED State: Not Blinking..\r\n");
   }
   
   PrintMessage("LED Speed: %02x \r\n",pReceiveBuffer[1]);
  }

   // reset buffer for next async out!
   Pipe_in_ep.ResetBuffer();

}



//#########################################################
// Blinky Start
//#########################################################

void CTC1130_USB_BlinkyLEDDlg::On_start_blinky() 
{
  PrintMessage("Blinking started!\r\n");
  WriteDevice('1');
}

//#########################################################
// Blinky Stop
//#########################################################

void CTC1130_USB_BlinkyLEDDlg::On_stop_blinky() 
{
  PrintMessage("Blinking stoped!\r\n");
	WriteDevice('0');
}

//#########################################################
// Blinky Faster
//#########################################################

void CTC1130_USB_BlinkyLEDDlg::On_faster_blink() 
{
  PrintMessage("Blinking frequency increased!\r\n");
	WriteDevice('+');
}

//#########################################################
// Blinky Slower
//#########################################################

void CTC1130_USB_BlinkyLEDDlg::On_slower_blink() 
{
  PrintMessage("Blinking frequency decreased!\r\n");
	WriteDevice('-');
}


