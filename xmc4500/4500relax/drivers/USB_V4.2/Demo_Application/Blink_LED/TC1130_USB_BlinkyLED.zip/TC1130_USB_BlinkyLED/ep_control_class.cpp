/******************************************************************************
*
*        Copyright (c) 1999-2003, Infineon Technologies AG
*              Infineon Confidential Proprietary
*
*******************************************************************************
* MODULE:
* $Id: ep_control_class.cpp,v 1.1.1.1 2006/01/03 11:57:21 dannebau Exp $
*
* VERSION:
* $Revision: 1.1.1.1 $
*
* $Date: 2006/01/03 11:57:21 $
*
* $Author: dannebau $
*
*******************************************************************************
* DESCRIPTION:  
*                                    
*******************************************************************************
* RELEASE HISTORY

$Log: ep_control_class.cpp,v $
Revision 1.1.1.1  2006/01/03 11:57:21  dannebau
BlinkyLED Example for TC1130 Triboard.
Has to be used with THESYCONS USBIO VL 2.31 only!

Revision 1.1.1.1  2004/06/28 12:18:49  dannebau
Intial version of special GUI for subsequent USB certification by Thesycon

******************************************************************************/

#include "ep_control_class.h"

DWORD ep_control_out_class::bind_ep (int dev_if,int ep_addr, HDEVINFO device_list,GUID* device_guid) 
{

  // open the pipe and bind the pipe 
  return pipe_ep.Bind(dev_if,ep_addr,device_list,device_guid);
}


DWORD ep_control_in_class::bind_ep (int dev_if,int ep_addr, HDEVINFO device_list,GUID* device_guid) 
{

  // open the pipe and bind the pipe 
  return pipe_ep.Bind(dev_if,ep_addr,device_list,device_guid);
}

