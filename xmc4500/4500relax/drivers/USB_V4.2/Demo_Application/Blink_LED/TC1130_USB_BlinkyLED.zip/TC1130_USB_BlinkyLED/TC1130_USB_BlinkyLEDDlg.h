/******************************************************************************
*
*        Copyright (c) 1999-2005, Infineon Technologies AG
*              Infineon Confidential Proprietary
*
******************************************************************************/


#if !defined(AFX_TC1130_USB_BlinkyLEDDLG_H__56159786_BE7B_4469_95D8_5F33E08A8C21__INCLUDED_)
#define AFX_TC1130_USB_BlinkyLEDDLG_H__56159786_BE7B_4469_95D8_5F33E08A8C21__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000



// Definition of USB class guid
#define USBClassGUID {0x36FC9E60, 0xC465, 0x11CF, {0x80, 0x56, 0x44, 0x45, 0x53, 0x54, 0x00, 0x00}}




// Index to be used for "GetConfigurationDescriptor"
// This parameter is greater than 0 for multiconfiguration devices only.
#define CONFIG_INDEX 1


#define CONFIG_NB_OF_INTERFACES 1

#define CONFIG_IF1          1
#define CONFIG_IF2          2
#define CONFIG_IF1_AS1      1
#define CONFIG_IF2_AS1      1
#define CONFIG_TRAN_SIZE    4096



// Define Adresses for TC1130 IF1 Endpoints
// bulkin
#define EP1_ADDRESS         0x81
// bulkout 
#define EP2_ADDRESS         0x02


// Definition for Packet Size (default 64 bytes)
#define MaxPktSize 64

// The device is defined by its USB Vendor ID and Product ID.
// Infineon Device (Metis or Cedar or Leda)
#define USB_VENDOR_ID   0x058b
// Product ID for USBIO light version
#define USB_PRODUCT_ID  0x001F

// Definitions for single XCP Messages
#define XCP_PID         16
#define XCP_LENGTH      30
#define XCP_VALUE       7  
#define XCP_OUT_DEFAULT 5
#define XCP_IN_DEFAULT  7
#define XCP_NB_OF_LOOPS_DEFAULT 70

// number of I/O buffers used
#define NB_OF_BUFFERS   5


class CTC1130_USB_BlinkyLEDDlg : public CDialog
{
// Construction
public:
    CTC1130_USB_BlinkyLEDDlg(CWnd* pParent = NULL);   // standard constructor
    ~CTC1130_USB_BlinkyLEDDlg();

    void CTC1130_USB_BlinkyLEDDlg::PrintError(DWORD);
    void CTC1130_USB_BlinkyLEDDlg::Start(int);
    void CTC1130_USB_BlinkyLEDDlg::INTHREAD();
    void CTC1130_USB_BlinkyLEDDlg::STOP_IN_THREAD();
    void CTC1130_USB_BlinkyLEDDlg::pattern_test();

   
    void WriteDevice(char c);

    //void CTC1130_USB_BlinkyLEDDlg::On_open_bind();
    char fehlermeldung[256];
    
    CHAR *global_ptr;
    
    ULONG file_state, no_of_bytes;
    
    UCHAR pSendBuffer[64];
	
	  // Helper Function for Automatic Device Notifiaction
	  BOOLEAN RegisterDevNotify(const GUID g_IFX_IF0_Guid, HDEVNOTIFY *hDevNotify);
    
    
    // Dialog Data
    //{{AFX_DATA(CTC1130_USB_BlinkyLEDDlg)
	  enum { IDD = IDD_TC1130_USB_BlinkyLED_DIALOG };
	  CButton	m_search_device_ctrl;
	  CButton	m_das_cnct_to_dev_ctrl;
	  CButton	m_async_out_ban_ctrl;
	  CButton	m_async_out_muc_ctrl;
	  CButton	m_close_device_pipes_ctrl;
	  CButton	m_inthread_stop;
	  CButton	m_inthread_start_ctrl;
	  CButton	m_search_endpoints_ctrl;
	  CButton	m_bind_in_button_ctrl;
	  CButton	m_bind_out_button_ctrl;
	  CButton	m_idc_button15;
	  CString m_Output;
	  int		  m_xcp_pid;
	  int		  m_xcp_length;
	  int		  m_xcp_value;
	  int		  m_xc_ep_out;
	  int		  m_xcp_ep_in;
	  int		  m_nb_of_loops;
	  BOOL	  m_if0_check;
	  BOOL	  m_if1_check;
	  BOOL	  m_if2_check;
	  BOOL	  m_if3_check;
    CButton	m_On_generic_testCTRL;
	//}}AFX_DATA

    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CTC1130_USB_BlinkyLEDDlg)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

// Implementation
protected:

    void PrintMessage(LPCTSTR pFormat, ...);
    CCriticalSection    m_OutputLock;   // synchronization mechanism for the output window
    HICON               m_hIcon;        // icon variable
    HANDLE              m_hKillEvent;   // this event is signaled when the app closes.  All
                                        // pending transfers should then be canceled
    HANDLE              m_hDevice;      // device handle
     
	  UCHAR*              CreateXCPPkts(UCHAR *pSendBuffer, int XCPPid, int XCPLen, int XCPVal);
    
    int                 CompPktBuffer(UCHAR *pCompBuffer, UCHAR *pSendBuffer, int size);

    // Automatic Device Notification
	  HDEVNOTIFY m_DevNotify;

   
	  // Kann wahrscheinlich weg:
    // bool m_InitialMove;

    // Generated message map functions
    //{{AFX_MSG(CTC1130_USB_BlinkyLEDDlg)
    virtual BOOL OnInitDialog();
    afx_msg void OnPaint();
    afx_msg HCURSOR OnQueryDragIcon();
    afx_msg void OnCancelioButton();
    afx_msg void OnBulk0Button();
    afx_msg void OnClose();
  	afx_msg void On_dnload_file();
  	afx_msg void On_open_bind();
  	afx_msg void On_close_dev_pipe();
    afx_msg void On_generic_test();
  	afx_msg void On_inthread_start();
	  afx_msg void On_stop_inthread();
   	afx_msg void On_nb_of_loops();
	  afx_msg void On_bind_bulkout_ep();
	  afx_msg void On_bind_bulkin_ep();
	  afx_msg void On_do_all_on_right_side();
	afx_msg void On_loop_over_test();
	afx_msg void On_start_blinky();
	afx_msg void On_stop_blinky();
	afx_msg void On_faster_blink();
	afx_msg void On_slower_blink();
	//}}AFX_MSG

    // handler for WM_DEVICE change
    afx_msg bool OnDeviceChange(UINT nEventType, DWORD dwData);
    DECLARE_MESSAGE_MAP()

};


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TC1130_USB_BlinkyLEDDLG_H__56159786_BE7B_4469_95D8_5F33E08A8C21__INCLUDED_)
