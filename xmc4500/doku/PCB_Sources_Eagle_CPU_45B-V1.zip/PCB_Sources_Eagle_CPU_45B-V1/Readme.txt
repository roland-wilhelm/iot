This folder contain following PCB design files based on Eagle V4.16r2 from Cadsoft (http://www.cadsoftusa.com):
xyz.sch           : Eagle Schematic file  
xyz.brd           : Eagle circuit board layout file
xyz.lbr           : Eagle library with all devices, contains symbols and footprints
Schematic_xyz.pdf : pdf format of the schematic
Assembly_xyz.pdf  : pdf format of the board, shows the position of devices on the PCB
