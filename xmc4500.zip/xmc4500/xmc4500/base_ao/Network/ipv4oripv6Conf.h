
// Valid for IPv6
	#define UIP_CONF_IPV6 1
