/******************************************************************************
*
*        Copyright (c) 1999-2005, Infineon Technologies AG
*              Infineon Confidential Proprietary
*
******************************************************************************/


#define MAX_TEST_PACKETS 2000

  // handle for device list
  HDEVINFO g_DevList = NULL;
  
  GUID g_UsbioID	  = USBIO_IID;
 
  
    
  // local USBIO device instance, used to configure the device
  CUsbIo Dev;

  // help variables
  USBIO_SET_CONFIGURATION Conf;

  // Output Endpoint Pipe  
  CUsbIoPipe Pipe_out_ep;

  // Input Endpoint Pipe
  CMyReader Pipe_in_ep(64 * MAX_TEST_PACKETS);
 
  DWORD Status = USBIO_ERR_FAILED;

  int packet_count = 1;
 
// #######################################################################
// Pattern Test
// #######################################################################

void CTC1130_USB_BlinkyLEDDlg::pattern_test()
{
 
  int i1;
  int pkt_cnt = 8;

  // Initialisation
  // The pSendBuffer stores all XCP Messages
  UCHAR pSendBuffer[64 * MAX_TEST_PACKETS];
  UCHAR *pSend = pSendBuffer;
  UCHAR pReceiveBuffer[64 * MAX_TEST_PACKETS];

  int NoPktReceived;

  i1 = 1;
  
 
  // Begin of Loop
  // XCP Packet will be created and sent to device
  for(i1=1; i1<= m_nb_of_loops; i1++) {
  
    if(pSend != NULL) {
      pSend = CTC1130_USB_BlinkyLEDDlg::CreateXCPPkts(pSendBuffer, 19, 44, i1); 
    } else {
      PrintMessage("Error Send Buffer Pointer Not valid, Pkt: %d !! \r\n", i1);
      //exit(1);
    }
  
    Sleep(100);

    // Check Status of In Thread
    if(!Pipe_in_ep.GetTransStatus()) {
      PrintMessage("Error detected for In Thread, Pkt: %d \r\n", i1);
      //exit(1);
    }


    NoPktReceived = Pipe_in_ep.GetData(pReceiveBuffer);
    if(NoPktReceived != 64) {
      PrintMessage("Error detected for In Thread, No Data Read( %d) , Pkt: %d !! \r\n", NoPktReceived, i1);
      //exit(1);
    }
    
    // Compare Buffers
    if(!CompPktBuffer(pReceiveBuffer, pSendBuffer, 64)) {
      PrintMessage("Error in Pkt: %d !! \r\n", i1);
      return;
    } else {
    
      PrintMessage("%d. Packet-Loop passed !! \r\n", i1);
          
    };

    // Reset Input Buffer for additional tests
    Pipe_in_ep.ResetBuffer();
  
  }

}

// #######################################################################
// Compare Buffers
// #######################################################################

int CTC1130_USB_BlinkyLEDDlg::CompPktBuffer(UCHAR *pCompBuffer, UCHAR *pSendBuffer, int size)
{
  int i1;

  // Compare pCompBuffer with data from EP7
  for(i1=0; i1 < size; i1++) {
     //PrintMessage("Data_IN %d -- Data_Comp %d \r\n", pSendBuffer[i1], pCompBuffer[i1]);
    if (pSendBuffer[i1] != pCompBuffer[i1]) {
      PrintMessage("Comp of data failed at pos :%d \r\n",i1);
      PrintMessage("Data_IN %d -- Data_Comp %d \r\n", pSendBuffer[i1], pCompBuffer[i1]);
      break;
    }
  }

  if(i1 == size ) {
    //PrintMessage("Compare of data passed at pos %d!  \r\n",i1);
    return 1;
  } else {
    PrintMessage("Compare of data failed at pos %d!  \r\n",i1);
    return 0;
  }
}



// #######################################################################
// Generation of one XCP Packet with given parameters PID, LENGTH and Value
// #######################################################################

UCHAR* CTC1130_USB_BlinkyLEDDlg::CreateXCPPkts(UCHAR *pSendBuffer,int XCPPid, int XCPLen, int XCPVal)

{
  int i1;
  int len;
  int XCP_Pkt_Len = 6;
  DWORD TransSize = 64;
  //DWORD TransSize = 40;

  // Sync Transfer
 
  const DWORD BufSize = 64;
  CUsbIoBuf BufferDesc(BufSize);


  if (XCPLen < 6) {
    len = XCP_Pkt_Len;
  } else {
    len = XCPLen;
  }

  // Create Data Buffer: Part I
  // Header for pSendBuffer
  pSendBuffer[0] = len;
  pSendBuffer[1] = 0x00;
  pSendBuffer[2] = 0x00;
  pSendBuffer[3] = 0x00;
  pSendBuffer[4] = XCPPid;
  // Create Date Buffer: Part II 
  for (i1=(5);i1<((len+4));i1++) {
      pSendBuffer[i1] = XCPVal;
  } 
  // SEND Data Buffer: Part III
  // Fill up of with zeros
  if ((len)<(((int)MaxPktSize-4))){
    for (i1=len+4; i1< (int)MaxPktSize; i1++)
    {
      pSendBuffer[i1] = 0x00;
    }
  } 

  // Sync Bulkout of 64 Byte to device
  
  Status = Pipe_out_ep.WriteSync(pSendBuffer,TransSize,1000);
  
  if ( Status != USBIO_ERR_SUCCESS ) {
    PrintMessage("Ooops! Synchronous write request failed!\r\n");
    PrintError(Status);
    return NULL;
  } else {
    return (pSendBuffer + (sizeof(UCHAR)*64));
  }

}


// #######################################################################
// Start INTHREAD
// #######################################################################

void CTC1130_USB_BlinkyLEDDlg::INTHREAD()
{

if ( !Pipe_in_ep.AllocateBuffers(64, 10) ) {
    PrintMessage("Unable to allocate buffer pool.\r\n");
    return;
  }
  // start the worker thread
  PrintMessage("Starting worker thread...\r\n");
  if ( !Pipe_in_ep.StartThread() ) {
    PrintMessage("Unable to start worker thread.\r\n");
    return;
  }
  PrintMessage("IN THREAD has been started.\r\n");
}



// #######################################################################
// Stop INTHREAD
// #######################################################################

void CTC1130_USB_BlinkyLEDDlg::STOP_IN_THREAD()
{
  // Shutdown Start_IN_THREAD  
  Pipe_in_ep.ShutdownThread();
  Pipe_in_ep.FreeBuffers();
  PrintMessage("IN THREAD has been stopped!\r\n");
}


//##################################################################
// Open Device IF2,bind the Pipes, configure the USB......
//##################################################################

void CTC1130_USB_BlinkyLEDDlg::On_open_bind() 
{
	
 

  // initialize the global event
  g_TerminateEvent = CreateEvent(NULL,TRUE,FALSE,NULL);
  if (g_TerminateEvent == NULL ) {
    PrintMessage("CreateEvent failed: Error %d .\r\n", GetLastError());
    return;
  } else { 
    PrintMessage("CreateEvent passed!\r\n");
    }
 
   g_DevList = CUsbIo::CreateDeviceList(&g_UsbioID);
   
 
  if ( g_DevList==NULL ) {
    PrintMessage("Unable to build a device list!\r\n");
    goto Exit;
  } else { 
    PrintMessage("Building of device list passed!\r\n");
    }

   // Open Device 
    Status = Dev.Open(1,g_DevList,&g_UsbioID);

  if ( Status != USBIO_ERR_SUCCESS ) {
    PrintMessage("Device open failed!\r\n");
    goto Exit;
  } else { 
    PrintMessage("Device open passed! \r\n");
    }

  // Configure CEDAR IF1 AS1
  ZeroMemory(&Conf,sizeof(Conf));
    
  //Conf.ConfigurationIndex = CONFIG_INDEX;
  Conf.ConfigurationIndex                     = 0;
  Conf.NbOfInterfaces                         = 1;
  Conf.InterfaceList[0].InterfaceIndex        = 1;
  Conf.InterfaceList[0].AlternateSettingIndex = 1;
  Conf.InterfaceList[0].MaximumTransferSize   = CONFIG_TRAN_SIZE;
 
  
  // Configure the device
  PrintMessage("Configuring the device...\r\n");
  Status = Dev.SetConfiguration(&Conf);

  if ( Status != USBIO_ERR_SUCCESS ) {
    PrintMessage("SetConfiguration failed \r\n");
    PrintError(Status);
    // Ignore the error: USBIO_ERR_ALREADY_CONFIGURED
    // Maybe another app has been started and the device is configured already.
    if (Status != USBIO_ERR_ALREADY_CONFIGURED) {
      goto Exit;
    }
  } else { 
    PrintMessage("Device configuration passed!\r\n");

    // Enable Search Endpoint Buttons
    //m_search_endpoints_ctrl.EnableWindow(TRUE);
    
  }


  Exit:
  if (g_DevList != NULL ) {
    CUsbIo::DestroyDeviceList(g_DevList);
  }
  if (g_TerminateEvent != NULL) {
    CloseHandle(g_TerminateEvent);
  }
}

// ##################################################################
//  Bind Ouput Pipe to Endpoint x
// ##################################################################


void CTC1130_USB_BlinkyLEDDlg::On_bind_bulkout_ep() 
{

   g_DevList = CUsbIo::CreateDeviceList(&g_UsbioID);
   Status = Pipe_out_ep.Bind(1,EP2_ADDRESS,g_DevList,&g_UsbioID);
  
  if ( Status != USBIO_ERR_SUCCESS ) {
    PrintMessage("Binding to pipe for Out EP2 failed!\r\n");
    goto Exit;
  } else { 
    PrintMessage("Binding to pipe for Out EP2 passed!\r\n");
    
  }

Exit:
  if (g_DevList != NULL ) {
    CUsbIo::DestroyDeviceList(g_DevList);
  }
  if (g_TerminateEvent != NULL) {
    CloseHandle(g_TerminateEvent);
  }
 
}

// ##################################################################
//  Bind Input Pipe to Endpoint y
// ##################################################################


void CTC1130_USB_BlinkyLEDDlg::On_bind_bulkin_ep() 
{
  
     g_DevList = CUsbIo::CreateDeviceList(&g_UsbioID);
     Status = Pipe_in_ep.Bind(1,EP1_ADDRESS,g_DevList,&g_UsbioID);
  

  if ( Status != USBIO_ERR_SUCCESS ) {
    PrintMessage("Binding to pipe for In EP1 failed!\r\n");
    goto Exit;
  } else { 
    PrintMessage("Binding to pipe for In EP1 passed!\r\n");

  }

  Exit:
  if (g_DevList != NULL ) {
    CUsbIo::DestroyDeviceList(g_DevList);
  }
  if (g_TerminateEvent != NULL) {
    CloseHandle(g_TerminateEvent);
  }
}


//##################################################################
// Close Device and Pipes
//##################################################################


void CTC1130_USB_BlinkyLEDDlg::On_close_dev_pipe() 
{

  // Destroy Device List
  CUsbIo::DestroyDeviceList(g_DevList);
  
  // Unbind CEDAR IF1 AS1 EP2
  Pipe_out_ep.Close();
 
  // Unbind CEDAR IF1 AS1 EP1
  Pipe_in_ep.Close();
  
  // Close CEDAR IF1
  Dev.Close();

  PrintMessage("Device IF1 and Pipes to Endpoints successfully closed!\r\n");
}


//##################################################################
//return string for pipe type  
//##################################################################


// return string for pipe type
const char* PipeTypeStr(USBIO_PIPE_TYPE PipeType)
{
	return (
		(PipeType==PipeTypeControl) ?			"Control" :
		(PipeType==PipeTypeIsochronous) ? "Isochronous" :
		(PipeType==PipeTypeBulk) ?				"Bulk" :
		(PipeType==PipeTypeInterrupt) ?		"Interrupt" :	"unknown"
		);
}


// return string for endpoint direction
const char* EndpointDirectionStr(UCHAR EndpointAddress)
{
	return ( (EndpointAddress&0x80) ?	"IN" : "OUT" );
}



// ##################################################################
//  Perform the complete test
// ##################################################################


void CTC1130_USB_BlinkyLEDDlg::On_do_all_on_right_side() 
{

  PrintMessage("This button is out of order!\r\n");
/*
  // Bind and configure Device
	CTC1130_USB_BlinkyLEDDlg::On_open_bind();
  
  // Open Bulkout Pipe to EPx
  CTC1130_USB_BlinkyLEDDlg::On_bind_bulkout_ep();

  // Open Bulkin Pipe to EPy
  CTC1130_USB_BlinkyLEDDlg::On_bind_bulkin_ep();

  // Start Read Thread
  CTC1130_USB_BlinkyLEDDlg::On_inthread_start();

  // Start Generic Pattern Test
  CTC1130_USB_BlinkyLEDDlg::On_loop_over_test();

  // Stop Read Thread
  CTC1130_USB_BlinkyLEDDlg::STOP_IN_THREAD();

  // Unbind Pipes and close Device
  CTC1130_USB_BlinkyLEDDlg::On_close_dev_pipe();

*/
}


// ##################################################################
// Generic Test
// ##################################################################

void CTC1130_USB_BlinkyLEDDlg::On_generic_test() 
{
 	UCHAR pSendBuffer2[1024];
  const DWORD BufSize = 1024;
  DWORD TransSize, i;
  CUsbIoBuf BufferDesc(BufSize);
  UCHAR pReceiveBuffer[1024];
  int NoPktReceived, a;
  

  
  for ( i=0; i<BufSize; i++ ) {
    pSendBuffer2[i] = (UCHAR)packet_count;
  }

  
  // Generate Buffer Header for DAS Server ( Connect to Device )
  pSendBuffer2[0]       = 0x00;
  pSendBuffer2[1]       = 0x4;
  pSendBuffer2[2]       = packet_count;
  pSendBuffer2[3]       = 0x0;
  
  // increase packet count
   packet_count++;

  // Copy the data
  memcpy((UCHAR*)BufferDesc.Buffer(),pSendBuffer2, BufSize);

  // set the length of the transfer in bytes
  TransSize = BufSize;
  
   
  BufferDesc.NumberOfBytesToTransfer = BufSize;
  
  // Write Asynchron
  Pipe_out_ep.Write(&BufferDesc);


  for (;;) {
      // wait for 100 ms 
      Status = Pipe_out_ep.WaitForCompletion(&BufferDesc,50);
      // check the status
      if (Status == USBIO_ERR_SUCCESS) {
          PrintMessage("Write async passed!\r\n");
          break;
      }   
      if (Status == USBIO_ERR_TIMEOUT) {
          PrintMessage("Write Sync not finished yet!\r\n");
      } else {
          PrintMessage("Write Sync failed! Any Other error\r\n");
          PrintError(Status);
          break;
      }
        
  }//for


  Sleep(50);

  // Get Received packets
  NoPktReceived = Pipe_in_ep.GetData(pReceiveBuffer);

  // Print received packets
  //PrintMessage("Received Pkts: %d\r\n",NoPktReceived);

  // Compare Buffers
  if(!CompPktBuffer(pReceiveBuffer, pSendBuffer2, 1024)) {
     PrintMessage("Error  \r\n");
     
     // Print out the sent packets
     for (a=0; a<BufSize; a++) {

         PrintMessage("%02x ",pSendBuffer2[a]);
         if (!((a+1)%8) && a!=0) {
         PrintMessage("\r\n");
     
         }
      }
  
     PrintMessage("------------------\r\n");
  
     // Print out the received packets
     for (a=0; a<NoPktReceived; a++) {

         PrintMessage("%02x ",pReceiveBuffer[a]);
         if (!((a+1)%8) && a!=0) {
            PrintMessage("\r\n");
         }
      }  
     
        // reset buffer for next async out!
        Pipe_in_ep.ResetBuffer();
        return;
      }

      PrintMessage("Single test 1024 Asyn done \r\n");
      // reset buffer for next async out!
      Pipe_in_ep.ResetBuffer();


}


// ##################################################################
//  Start IN Thread from Generic Test
// ##################################################################


void CTC1130_USB_BlinkyLEDDlg::On_inthread_start() 
{
CTC1130_USB_BlinkyLEDDlg::INTHREAD();
}

// ##################################################################
//  Stop IN Thread from Generic Test
// ##################################################################

void CTC1130_USB_BlinkyLEDDlg::On_stop_inthread() 
{
CTC1130_USB_BlinkyLEDDlg::STOP_IN_THREAD();
}



