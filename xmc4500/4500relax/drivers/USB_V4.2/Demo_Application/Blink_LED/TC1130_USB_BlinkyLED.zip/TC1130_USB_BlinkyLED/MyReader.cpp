/******************************************************************************
*
*        Copyright (c) 1999-2005, Infineon Technologies AG
*              Infineon Confidential Proprietary
*
*******************************************************************************

*/

/********************************** Includes *****************************/
// Windows
#include <windows.h>
// standard libraries
#include <stdio.h>
#include <conio.h>
#include <malloc.h>
#include <stdlib.h>

#include "MyReader.h"

// default constructor
CMyReader::CMyReader(int ByteSize)
{
  actual_ptr      = NULL;
  BufferByteSize  = 0;
  BufferPtr       = NULL;
  TransStatus     = 0;
  NoBytesRead     = 0;


  BufferPtr = (UCHAR*)malloc(ByteSize);
  if(BufferPtr != NULL) {
    BufferByteSize = ByteSize;
    actual_ptr = BufferPtr;
    TransStatus = 1;
  } else {
    exit(-1);
  }
}

// destructor
CMyReader::~CMyReader()
{
  if(BufferPtr != NULL) {
    free(BufferPtr);
  }
}


// Called by the base class if a read operation completes
void CMyReader::ProcessData(CUsbIoBuf* Buf)
{
  if ( Buf->Status==USBIO_ERR_SUCCESS ) {
    // read operation completed successfully

        
    
    if(Buf->BytesTransferred % 64 != 0) {
      TransStatus = 1;
      exit(-1);
    }

    if(NoBytesRead < BufferByteSize) {
      memcpy(actual_ptr, Buf->Buffer(), Buf->BytesTransferred);
      actual_ptr += Buf->BytesTransferred * sizeof(UCHAR);
      NoBytesRead += Buf->BytesTransferred;

      TransStatus++;
    }
  } else {
    // read operation completed with error
    TransStatus =0;
    //char strbuf[256];
    //fprintf(stderr,"ProcessData: %s\n",CUsbIo::ErrorText(strbuf,sizeof(strbuf),Buf->Status));
  }

}


UCHAR * CMyReader::return_p(void)
{
return actual_ptr;
}


// Get Transfer Status
int CMyReader::GetTransStatus(void)
{
  return TransStatus;
}

// Get Number of Bytes Read
int CMyReader::GetNoBytesRead(void)
{
  return NoBytesRead;
}

// Get Buffer Pointer
UCHAR* CMyReader::GetBufferPtr(void)
{
  return BufferPtr;
  }

// Reset Buffer
void CMyReader::ResetBuffer(void)
{
  actual_ptr = BufferPtr;
  NoBytesRead = 0;
}


// Get Data
int CMyReader::GetData(UCHAR* pBuffer)
{
  if(BufferPtr != NULL && NoBytesRead > 0) {
    memcpy(pBuffer, BufferPtr, NoBytesRead);
    return NoBytesRead;
  } else {
    return 0;
  }
}

/************************************ EOF *********************************/
